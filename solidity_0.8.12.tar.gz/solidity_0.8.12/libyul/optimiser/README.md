# Yul-Based Optimizer

The documentation of the Yul-based optimizer module has been moved to the official Solidity documentation.

Please refer to the [optimizer documentation](/docs/internals/optimizer.rst) for a description of all optimization stages and how to use the optimizer and to the [Yul documentation](/docs/yul.rst#optimization-step-sequence) for more information on the optimization step sequence and a list of abbreviations for each step.